 #ifndef _outputdata_H
#define _outputdata_H

extern float OutData[4];
void OutPut_Data(void);
#endif 


