/********************************************
����MC9S12XS128�๦�ܿ����� 
Designed by Chiu Sir
E-mail:chiusir@yahoo.cn
�����汾:V2.2
������:2014��1��5��
�����Ϣ�ο����е�ַ:
��վ:  http://www.lqist.cn
��̳:  http://smartcar.5d6d.com
�Ա���:http://shop36265907.taobao.com   
------------------------------------
Code Warrior 5.0
Target : MC9S12XS128
Crystal: 16.000Mhz
busclock:32.000MHz
pllclock:64.000MHz 
**********************************************/
#ifndef _ADC_H
#define _ADC_H
extern volatile uint AD_max_data0;
extern volatile uint AD_max_data1;
extern volatile uint AD_min_data0;
extern volatile uint AD_min_data1;

extern volatile uint AD_max_data2;
extern volatile uint AD_max_data3;
extern volatile uint AD_min_data2;
extern volatile uint AD_min_data3;

extern volatile uint AD_max_data4;
extern volatile uint AD_max_data5;
extern volatile uint AD_min_data4;
extern volatile uint AD_min_data5;
 
 
void delay(void) ;
extern void AD_collect(void); 
extern void AD_init(void); 
 

#endif