                                                
   #ifndef _CALCULATOR_H_
   #define _CALCULATOR_H_
                                           
   void BubbleSort(int array[]);  
   
   #endif