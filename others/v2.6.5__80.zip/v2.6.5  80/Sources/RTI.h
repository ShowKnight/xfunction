#ifndef _RTI_H_
#define _RTI_H_


void INIT_RTI(void);
 

#endif