#include "main.h" 

void BubbleSort(int array[])  
{  
   int i,j,temp;  
     for(j=0;j<5;j++)  
       for(i=1;i<5-j;i++)  
         if(array[i]>array[i+1])  
          {  
              temp=array[i];  
              array[i]=array[i+1];  
              array[i+1]=temp;  
           }  
}  