/********************************************
����MC9S12XS128�๦�ܿ����� 
Designed by Chiu Sir
E-mail:chiusir@yahoo.cn
�����汾:V2.2
������:2014��1��5��
�����Ϣ�ο����е�ַ:
��վ:  http://www.lqist.cn
��̳:  http://smartcar.5d6d.com
�Ա���:http://shop36265907.taobao.com   
------------------------------------
Code Warrior 5.0
Target : MC9S12XS128
Crystal: 16.000Mhz
busclock:32.000MHz
pllclock:64.000MHz 
**********************************************/
#ifndef _Uart_H
#define _Uart_H


static void delayms(int ms);
extern  void Sci0_Sendc(unsigned char c);
extern  void Sci0_Sends(char ch[]);
extern  void Sci0_Sendnc(char ch[],int num);
extern  void Sci1_Sendc(unsigned char c);
extern  void Sci1_Sends(char ch[]);
extern  void Sci1_Sendnc(char ch[],int num);

extern  void Sci0_Init(void);
extern  void Sci1_Init(void);
extern  unsigned char Sci0_Receive(void); 
extern  unsigned char Sci1_Receive(void); 




#endif
