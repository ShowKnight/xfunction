#ifndef _UserDefinedFun_H
#define _UserDefinedFun_H

#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

void Delay_ms(uint);
void Delay_us(uint);
//uint fabs(int);

#endif