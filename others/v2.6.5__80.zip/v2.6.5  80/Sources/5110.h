#ifndef _5110_H
#define _5110_H

#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

#include "Userdefine.h"

//λ��������
/*
#define LCD_CE   PORTK_PK3
#define LCD_RST  PORTK_PK2
#define LCD_DC   PORTK_PK1
#define SDIN     PORTK_PK0
#define SCLK     PORTK_PK5 
*/
#define LCD_CE   PTM_PTM2
#define LCD_RST  PTM_PTM0
#define LCD_DC   PTM_PTM3
#define SDIN     PTM_PTM4
#define SCLK     PTM_PTM5 


//��������
void LCD_Init(void);
void LCD_clear(void);
void LCD_write_byte(uchar, uchar);
void LCD_set_XY(uchar , uchar );      
void LCD_write_char(uchar );
void LCD_Write_Char(uchar ,uchar ,uchar);
void LCD_Write_Num(uchar ,uchar ,uint,uchar);
void LCD_write_english_string(uchar ,uchar ,char *); 
void LCD_write_chinese(uchar , uchar , char *);
void LCD_write_chinese_string(uchar , uchar ,char *);
void LCD_Write_String(uchar , uchar ,char *);
void LCD_draw_bmp_pixel(uchar ,uchar ,uchar *, uchar ,uchar );

#endif