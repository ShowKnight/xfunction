 
#include "main.h"

/*************************************************************/
/*                        ��ʼ��PWM                          */
/*************************************************************/
void PWM_Init(void) 
 {
  PWMCTL_CON23 = 1;   
  PWMCTL_CON01 = 1; //����0�ź�1��ͨ���γ�16λPWMͨ����,��PWM1���
  PWMCTL_CON45 = 1;
  
  PWMPOL = 0xff;   
  
  PWMPRCLK = 0x50;   //B:2MHz   A:64MHz
  
  PWMSCLB  =  1;                          
  PWMSCLA  =  1;     //CLOCK SB=CLOCK B/(2*PWMSCLA)=1M;  SA=32M; FBI warning:They can't be ZERO!!!!when==0,they=256;
 
  PWMCLK = 0xff;      //ͨ��SA/SBʱ����Ϊʱ��Դ
  PWMPER23  = 20000;   //ͨ��23��Ϊ50Hz 
  PWMDTY23  = 1463;     //�м�ֵ 
  
  PWMPER01 = 2000;             
  PWMPER45 = 2000; // 01/45:16khz
  PWMPER6 = 200;
  PWMPER7 = 200;
  
  PWMDTY01 = 800;
  PWMDTY45 = 800;
  PWMDTY6 = 0;
  PWMDTY7 = 0;
  
  PWME = 0xea;    //ʹ��ͨ��
 }