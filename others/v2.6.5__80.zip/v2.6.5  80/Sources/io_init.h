#ifndef _IO_INIT_H_
#define _IO_INIT_H
void io_init(void);

#endif