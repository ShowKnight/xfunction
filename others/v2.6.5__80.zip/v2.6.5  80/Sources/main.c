#include "main.h"
#include<string.h>

 
#define BUS_CLOCK 64000000  //BUSCLOCK=64M
#define BAUD 9600

uint qz,qv;
int get_flag = 0;
char post_flag = 0;
int show_flag = 0;

uint num = 0;

uchar data_receive0,data_receive1;      //receive interrupt data
char txtbuf1[30];    //for show
char txtbuf2[30];    //for show


char mode[15] = "AT+CMGF=1\r";
char phone[30] = "AT+CMGS=\"1252013618377231\"\r";
 

char sms[30] = "Hello my dream!\x01a"; 

char call[20] ="ATD13220261504;\r" ; 
char message[20]; 
char pmessage[20]="\nmeage:\n";



char s1[33] = "AT+CLPORT=\"TCP\",\"2000\"\r\n"; //���ص����ö˿ں���������
char s2[54] = "AT+CIPSTART=\"TCP\",\"120.24.85.14\",\"80\"\r\n";//Զ�̷�����ip���˿�
char s3[14] = "AT+CIPSEND\r\n";                  //��ʼ����

char g1[31] = "GET /status/get HTTP/1.1\r\n" ;//����get����
char g2[26] = "Host:120.24.85.14:80\r\n";   //����ĵ�ַ
char g3[20] = "Connection:close\r\n";



/*
char s1[33] = "AT+CLPORT=\"TCP\",\"2000\"\r";
char s2[54] = "AT+CIPSTART=\"TCP\",\"120.24.216.14\",\"7070\"\r";
char s3[14] = "AT+CIPSEND\r";

char g1[28] = "GET /status/get HTTP/1.1\r\n" ;
char g2[26] = "Host:120.24.216.14:7070\r\n";
char g3[18] = "Connection:close ";    
*/



char e1[18] = "AT+CIPCLOSE=1\r\n" ;

char p1[23] = "POST /posts HTTP/1.1\r\n"; //����ķ�ʽ��POST��Э����HTTP1.1
char p2[26] = "Host: 120.24.85.14:80\r\n";//Զ������ip��˿�
char p3[21] = "Connection: close\r\n";//����״̬��close�������������ݼ��ر�
char p4[17] = "Content-Length: ";//����
char p5[7];  //���ݳ���
char p6[25] = "\r\n\r\npost%5Bcontent%5D=";//���͵��������ύ��λ��

char string_posta[21];
char string_postb[21];

char start_posta = 0;
char start_postb = 0;

int buffer_size = 22;
uchar start_rec = 0;
uchar start_fix = 0;
int str_length = 0;
int test_a = 1;
int test_b = 1;


// might need to increase buffer size for high baud rates

char rx0_buffer[22];
int rx0_in=0;
char rx1_buffer[22];
int rx1_in=0;


void delayms(int ms)            //��ʱ����
{   
    uint i,j;
    for(i=0;i<ms;i++)
    for(j=0;j<3000;j++); 
}

void sub_str(char *src,char *des,int start,int lenth)
{
    int i;
    int j =0;
    for(i = start;i<start+lenth;i++)
    {
        des[j++] = src[i];
    }
    des[j]='\0';
}

void gprs_get()
{
    Sci0_Sends(s1); 
    delayms(200);
    Sci0_Sends(s2);
    delayms(8000);
    Sci0_Sends(s3);
    delayms(200);

    Sci0_Sends(g1);
    //delayms(1200);

    Sci0_Sends(g2);
    //delayms(1200);
    Sci0_Sends(g3);
    //delayms(1000);
    Sci0_Sends("\r\n\x01A");

    delayms(7000);
    Sci0_Sends(e1);  
}

void gprs_post()
{
    Sci0_Sends(s1);    
    delayms(200);
    Sci0_Sends(s2);
    delayms(8000);
    Sci0_Sends(s3);
    delayms(200);

    Sci0_Sends(p1);
    Sci0_Sends(p2);
    Sci0_Sends(p3); 
    Sci0_Sends(p4);  //content-legth

    str_length = strlen(p6) + strlen(string_posta)+ strlen(string_postb)+4;

    (void)sprintf(p5,"%d",str_length);
    Sci0_Sends(p5);  //����
    Sci0_Sends(p6);  // content��**
    Sci0_Sends(string_posta);
    Sci0_Sendc(':');
    Sci0_Sends(string_postb);
    Sci0_Sendc(':');
    Sci0_Sends("xz2f");

    delayms(1000);
    Sci0_Sends("\r\n\x01A");

    delayms(7000);
    Sci0_Sends(e1); 
}

void sms_send()
{

    if(PTJ_PTJ1==0)
          {
              //LCD_clear();
              // qz=0;
              //(void)sprintf(txtbuf3,"clear....");
              //LCD_write_english_string(3,0,txtbuf3);
              /* send_string(mode);
              delayms();
              send_string(phone);
              delayms();
              send_string(sms);
              delayms();*/

              Sci0_Sends(mode);
              delayms(2000);

              Sci0_Sends(phone);
              delayms(2000);
              
              (void)sprintf(txtbuf1,"Q:%.1f,M:%.2f  ",(float)qz/10,(float)qz*0.0005);
              Sci0_Sends(txtbuf1);
                 Sci0_Sends(sms);
              //SCI_send(0x1A);
              delayms(2000);
              //  send_string(call);
          }
}



void main(void) 
{

    char wen1[3];
    char shi1[3];
    char nong1[5];
    char deng1[4];
    char wen2[3];
    char shi2[3];
    char nong2[5];
    char deng2[4];
    DisableInterrupts;
    INIT_PLL(PLL64) ;  //��ʼ������64M
    
    //AD_init();
    Sci0_Init();
    Sci1_Init();
     
    io_init();
    LCD_Init();
    INIT_PIT();//0��1 ����50ms
    PITCE_PCE1 = 0;//�رն�ʱ��1��


    LCD_write_english_string(0,0,"Welcome to IOT");
    LCD_write_english_string(5,0,"SLQ");                 

    EnableInterrupts;
    
    string_posta[0] = '\0';
    string_postb[0] = '\0';
       
    num =0;
    for(;;) 
    {     
                              
        if(get_flag==1)    //get  ����
        {
          get_flag = 0; 
          gprs_get();
          
         // Sci1_Sendc(\x1A);
          /*Sci1_Sends(e2);  */      
               
        }
        
        if( post_flag==1 && start_posta ==1 && start_postb == 1)   // post ����
        {
            post_flag = 0;
            gprs_post(); 
            start_posta = 0;
            start_postb = 0;
            //string_posta[0] = '\0';
            //string_postb[0] = '\0';
         }
        
         
        if(start_posta==1)
        {
            //show_flag = 0;
            sub_str(string_posta,wen1,2,2); 
            sub_str(string_posta,shi1,5,2); 
            sub_str(string_posta,nong1,8,4);
            if(string_posta[13]=='1')  strcpy(deng1,"ON\0");
            else strcpy(deng1,"OF");
            (void)sprintf(txtbuf1,"w1:%s,s1:%s,n1:%s,d1:%s",wen1,shi1,nong1,deng1);                   
            LCD_write_english_string(1,4,txtbuf1);                 
            //Sci1_Sends(txtbuf1);           
            
         /*  sub_str(string_postb,wen2,2,2); 
           sub_str(string_postb,shi2,5,2); 
           sub_str(string_postb,nong2,8,4);
           if(string_postb[13]=='1')  strcpy(deng2,"ON\0");
           else strcpy(deng2,"OF");
           (void)sprintf(txtbuf1,"w2:%s,s2:%s,n2:%s,d2:%s",wen2,shi2,nong2,deng2);                   
           LCD_write_english_string(3,4,txtbuf1);   */              
            //Sci1_Sends(txtbuf1);                         
        }
        if(start_postb==1 )
        {
           //showflag = 0;
           sub_str(string_postb,wen2,2,2); 
           sub_str(string_postb,shi2,5,2); 
           sub_str(string_postb,nong2,8,4);
           if(string_postb[13]=='1')  strcpy(deng2,"ON\0");
           else strcpy(deng2,"OF");
           (void)sprintf(txtbuf1,"w2:%s,s2:%s,n2:%s,d2:%s",wen2,shi2,nong2,deng2);                   
           LCD_write_english_string(3,4,txtbuf1);                 
            //Sci1_Sends(txtbuf1);                  
         }  
    }
}

#pragma CODE_SEG __NEAR_SEG NON_BANKED

void interrupt  66 PIT0_inter(void) //���
{	
     static int i=0;
     static int j =0;
     i++;
     PITTF = 0x01; 
     if(i==150) //7.5s
     {
        //Sci1_Sends("10sok"); 
        get_flag = 1;   
     }
  
     if(i==300) //15s
     {
        i = 0;
        j++;
        get_flag = 1;         
        post_flag = 1;
        show_flag = 1;
        if(j==2)     //������������ߵ����
        {
            j = 0;
            if(test_a == 1)  //������
            {
               LCD_write_english_string(12,0,"ANO");
               //������
            }
            if(test_a == 0)  //����
            {
               LCD_write_english_string(12,0,"AOK");
               test_a = 1;
            }
            if(test_b == 1)  //������
            {
                 LCD_write_english_string(15,0,"BNO");
            }
            if(test_b == 0)  //����
            {
                 LCD_write_english_string(15,0,"BOK");
                 test_b = 1;
            }     
        }
     }
}

void interrupt  67 PIT1_inter(void) //send v & V value
{
     static int j=0;
     PITTF = 0x02; 
     j++;
     if(j==100)
     {
        j=0;
        //Sci1_Sends("5sok");        
     }
}

void interrupt  68 PIT2_inter(void)        // left for test
{                                     
    PITTF = 0x08 ;
}

void interrupt 24 PORTJ_ISR(void)                // EXIT PORTJ1
{         
  PIFJ_PIFJ1 = 1;   //����жϱ�־  
}

void interrupt 25 PORTH_ISR(void)             //EXIT PORTH7,any ports enableinterrupt,indeed
{
  PIFH_PIFH7 = 1;   //����жϱ�־λ     
}

void interrupt 20 Sci0_get()             //Receive interrupt ����GPRS
{
 	data_receive0 = Sci0_Receive();   //��SCI���յ����ݴ��͸�data_receive����
	//Sci1_Sendc(data_receive0);    //�����Ƿ���ȷ�ķ���.�����gprs���ظ���Ƭ��������
	if(data_receive0 == '{')  
	{
	  rx0_in  = 0;
	  start_rec = 1;
	}

	if(start_rec == 1)
	{
	   rx0_buffer[rx0_in] = data_receive0;
	   rx0_in = (rx0_in + 1) % buffer_size;
     if(data_receive0 == '}')
     {
         //Sci1_Sendc(data_receive0);   
        start_rec  = 0;                          
        rx0_buffer[rx0_in]='\0';
        //Sci1_Sends(rx0_buffer); //��ȡ�����ַ���
        rx0_in = 0 ;

        if (rx0_buffer[2]=='D')
        {
           if(rx0_buffer[6]=='1'&&rx0_buffer[7]=='1')  
           {
              Sci1_Sends("1l12l1");
           }
           if(rx0_buffer[6]=='1'&&rx0_buffer[7]=='0')  
           {
            
                Sci1_Sends("1l12l0");
           }
                
           
           if(rx0_buffer[6]=='0'&&rx0_buffer[7]=='0')  
           {
              Sci1_Sends("1l02l0");
           }
           if(rx0_buffer[6]=='0'&&rx0_buffer[7]=='1') 
           {
               Sci1_Sends("1l02l1");
           }
        }
        if(rx0_buffer[2]=='F')
        {
           //Sci1_Sends(rx0_buffer); 
        }

     }   
	}	 
	
	/*rx0_buffer[rx0_in] = data_receive0;
    rx0_in = (rx0_in + 1) % buffer_size;
    if(rx0_in == 10)
    {
        flag  = 1;
        rx0_in = 0 ;
    } */
} 
void interrupt 21 Sci1_get()             //Receive interrupt���� ���ڵ�
{
    data_receive1 = Sci1_Receive();   //��SCI���յ����ݴ��͸�data_receive����
    /*Sci0_Sendc(data_receive1);
    if(data_receive1 =='g') get_flag = 1;
    if(data_receive1 =='p') post_flag = 2;
    if(data_receive1 == 'w')  Sci0_Sends("\r\n\x01A");
    if(data_receive1 == 'r')  Sci0_Sends("\r\n\x01a");
    */
 //�˴����� Aok��Bok������ʱ��ok��ʱ��ŷ���post�����ݵķ���
   	if(data_receive1 == 'Y')   
   	{
   	  rx1_in = 0;
   	  start_fix = 1;
   	}
   	if (start_fix == 1)
   	{ 
   	  rx1_buffer[rx1_in] = data_receive1;
      rx1_in = (rx1_in + 1) % buffer_size;
      
      if(rx1_in == 14)
      {
        
       // Sci1_Sends("Aok");
        test_a=0;
        start_fix  = 0;                          
        rx1_buffer[rx1_in]='\0';
        //Sci1_Sends(rx0_buffer); //��ȡ�����ַ���
        string_posta[0]='\0';
        (void)strcpy(string_posta,rx1_buffer);
        rx1_in = 0 ;        start_posta = 1;

      }
   	}
   	
   	if(data_receive1 == 'X' )   start_fix = 2;
   	if (start_fix == 2)
   	{ 
   	  rx1_buffer[rx1_in] = data_receive1;
      rx1_in = (rx1_in + 1) % buffer_size;
      
      if(rx1_in == 14)
      {
         test_b = 0;
         //Sci1_Sends("Bok");
         start_fix  = 0;                          
         rx1_buffer[rx1_in]='\0';
        //Sci1_Sends(rx0_buffer); //��ȡ�����ַ���
        string_postb[0]='\0';

        (void)strcpy(string_postb,rx1_buffer);
        start_postb = 1;
        rx1_in = 0 ;
      }
   	}
} 

void interrupt 15 Timer_IC7()
{
     
}
void interrupt 14 Timer_IC6()
{
    
}
void interrupt 6 irq() 
{
    //static uchar  step=0;
   /* step++;
    PTH&=0xfe;
    if(step==2)
    {
      PWME=0x08;
      step=0;
    }
    delayms(1000);
    PTH|=0x01;*/
}
void interrupt 7 RTI()
{   
    CRGFLG_RTIF = 1;
}

#pragma CODE_SEG DEFAULT               
 
