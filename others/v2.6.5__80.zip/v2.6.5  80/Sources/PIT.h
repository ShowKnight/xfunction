#ifndef _PIT_H_
#define _PIT_H_

void INIT_PIT (void);
void Timer_init(void);
#endif