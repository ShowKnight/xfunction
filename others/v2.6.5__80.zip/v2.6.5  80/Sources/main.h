/********************************************
Code Warrior 5.0
Target : MC9S12XS128
Crystal: 16.000Mhz
busclock:64.000MHz
pllclock:128.000MHz 
**********************************************/
#ifndef _MAIN_H
#define _MAIN_H
#include <hidef.h>           /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
#include <MC9S12XS128.h>
#include <math.h>
#include <stdio.h>

#include "Set_Bus.h"
#include "Uart.h"

#include "PWM.h"
#include "ADC.h"  
#include "RTI.h"  
#include "PIT.h" 
#include "outputdata.h"  
#include "io_init.h"
#include "5110.h"

#pragma LINK_INFO DERIVATIVE "MC9S12XS128"
#endif