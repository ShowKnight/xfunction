package com.example.lonqi.environmentmonitoring;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;


public class Register extends ActionBarActivity implements View.OnClickListener{

    Button bRegister;
    EditText etUsername,etPassword,etEmail;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        bRegister = (Button)findViewById(R.id.bRegister);
        etUsername =(EditText)findViewById(R.id.etUsername);
        etPassword =(EditText)findViewById(R.id.etPassword);
        etEmail = (EditText)findViewById(R.id.etEmail);

        bRegister.setOnClickListener(this);

    }
    public void onClick(View v){
        switch (v.getId()){
            case R.id.bRegister:
                //startActivity(new Intent(this,MainActivity.class));
                break;
        }
    }


}
