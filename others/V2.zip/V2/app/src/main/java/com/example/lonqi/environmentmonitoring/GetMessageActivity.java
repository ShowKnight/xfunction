package com.example.lonqi.environmentmonitoring;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class GetMessageActivity extends ActionBarActivity {

    //private static final String DEBUG_TAG = "HttpExample";
    //private EditText urlText;
    //private TextView textView;
    String message="que";
    String Tag = "1234";
    String parsedmessage="No result";
    @Override
    public void onCreate(Bundle savedInstanceState) {

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        String getbutton = intent.getStringExtra(MainActivity.EXTRA_MESSAGE);

        String url="http://www.xfunction.pub/status/apitest";

        if(getbutton.equals("onall")) {
            url = "http://www.xfunction.pub/status/apionall";
        }
        if(getbutton.equals("offall")) {
             url = "http://www.xfunction.pub/status/apioffall";
        }
        if(getbutton.equals("ond1")) {
            url = "http://www.xfunction.pub/status/apiond1";
        }
        if(getbutton.equals("offd1")) {
            url = "http://www.xfunction.pub/status/apioffd1";
        }
        if(getbutton.equals("ond2")) {
            url = "http://www.xfunction.pub/status/apiond2";
        }
        if(getbutton.equals("offd2")) {
            url = "http://www.xfunction.pub/status/apioffd2";
        }

        message = sendHttpRequst(url);

        if(message.indexOf("00",8) !=-1)
        {
            parsedmessage="All off";
        }
        else if(message.indexOf("11",8) !=-1)
        {
            parsedmessage="All on";
        }
        else if(message.indexOf("10",8) !=-1)
        {
            parsedmessage="D1 on, D2,off";
        }
        else if(message.indexOf("01",8) !=-1)
        {
            parsedmessage="D1 off, D2,on";
        }
        else
        {
            parsedmessage="No result";
        }

        TextView textView = new TextView(this);
        textView.setTextSize(80);
        textView.setText(parsedmessage);
        Log.e(Tag, message);
        setContentView(textView);
        //println(message);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_get_message, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean isConnected(){
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }
    public String sendHttpRequst (String apiUrl){
        HttpURLConnection conn = null;
        InputStream is = null;
        ByteArrayOutputStream baos = null;
        if (isConnected()) {
            try {
                URL url = new URL(apiUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.connect();
                is = conn.getInputStream();
                int len = conn.getContentLength();
                if (len < 1) len = 1024;
                baos = new ByteArrayOutputStream(len);
                byte[] buffer = new byte[1024];
                len = 0;
                while ((len = is.read(buffer)) != -1) {
                    baos.write(buffer, 0, len);
                }
                return baos.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (baos != null) baos.close();
                    if (is != null) is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (conn != null) conn.disconnect();
            }
            return null;
        }
        else {
            return "Network problem!";
        }
    }
/*

    public static String GET(String url){
        InputStream inputStream = null;
        String result = "";
        try {

            // create HttpClient
            HttpClient httpclient = new DefaultHttpClient();

            // make GET request to the given URL
            HttpResponse httpResponse = httpclient.execute(new HttpGet(url));

            // receive response as inputStream
            inputStream = httpResponse.getEntity().getContent();

            // convert inputstream to string
            if(inputStream != null)
                result = convertInputStreamToString(inputStream);
            else
                result = "Did not work!";

        } catch (Exception e) {
            Log.d("InputStream", e.getLocalizedMessage());
        }

        return result;
    }

    // convert inputstream to String
    private static String convertInputStreamToString(InputStream inputStream) throws IOException{
        BufferedReader bufferedReader = new BufferedReader( new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        return result;

    }

    public boolean isConnected(){
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }


    public void myClickHandler(View view) {
        // Gets the URL from the UI's text field.
        //String stringUrl = urlText.getText().toString();
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected()) {
            new DownloadWebpageText().execute(stringUrl);
        } else {
            textView.setText("No network connection available.");
        }
    }

    private class DownloadWebpageText extends AsyncTask <String,String, String>{
       // @Override

        String user;
        String pass;

       protected void onPreExecute(String uname, String passwd)
       {
           user = uname;
           pass = passwd;
       }

        protected String doInBackground(String... urls) {
            try {
                String result;
                result = downloadUrl(urls[0]);
                return result;
            }
            catch (IOException e) {
                return "Unable to retrieve web page. URL may be invalid.";
            }
        }
        // onPostExecute displays the results of the AsyncTask.
        //@Override
        protected void onPostExecute(String result) {
            textView.setText(result);
        }
    }

    private String downloadUrl(String myurl) throws IOException {
        InputStream is = null;
        // Only display the first 500 characters of the retrieved
        // web page content.
        int len = 500;

        try {
            URL url = new URL(myurl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setReadTimeout(10000 );
            conn.setConnectTimeout(15000 );
            conn.setRequestMethod("GET");
            conn.setDoInput(true);
            // Starts the query
            conn.connect();
            int response = conn.getResponseCode();
            Log.d(DEBUG_TAG, "The response is: " + response);
            is = conn.getInputStream();

            // Convert the InputStream into a string
            String contentAsString = readIt(is, len);
            return contentAsString;

            // Makes sure that the InputStream is closed after the app is
            // finished using it.
        } finally {
            if (is != null) {
                is.close();
            }
        }
    }

    public String readIt(InputStream stream, int len) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        char[] buffer = new char[len];
        reader.read(buffer);
        return new String(buffer);
    }


*/
}
