package com.example.lonqi.environmentmonitoring;

import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class Login extends  ActionBarActivity implements View.OnClickListener {


    Button bLogin;
    EditText etUsername,etPassword;
    TextView tvRegisterlink,tvTest;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        new Thread(new Runnable() {
            @Override
            public void run() {

            }
        }).start();


        bLogin = (Button)findViewById(R.id.bLogin);
        etUsername =(EditText)findViewById(R.id.etUsername);
        etPassword =(EditText)findViewById(R.id.etPassword);
        tvRegisterlink = (TextView)findViewById(R.id.tvRegisterlink);
        tvTest = (TextView)findViewById(R.id.tvText);
        bLogin.setOnClickListener(this);
        tvRegisterlink.setOnClickListener(this);

    }

    public void onClick(View v){
        switch (v.getId()){
            case R.id.bLogin:
                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                if(validation(username,password)) {
                    startActivity(new Intent(this, MainActivity.class));
                    //startActivityForResult(new Intent(this, MainActivity.class),2);
                    this.finish();
                }
                else{
                }
                break;

            case R.id.tvRegisterlink:
                startActivity(new Intent(this,Register.class));
                break;
        }
    }

    public boolean validation(String username,String password){

        int ycross = 250;
        if(username.equals("") && !password.equals("")){
            String text = "Please input your username.";
            //tvTest.setText(text);

            Toast toast = Toast.makeText(getApplicationContext(),text, Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,ycross);
            toast.show();
            return false;
        }
        if(password.equals("") && !username.equals("")){
            String text = "Please input your password.";
            //tvTest.setText(text);
            Toast toast = Toast.makeText(getApplicationContext(),text, Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP|Gravity.CENTER,0,ycross);
            toast.show();
            return false;
        }
        if(password.equals("") && username.equals("")){
            String text = "Please input your username and password.";
            //tvTest.setText(text);

            Toast toast = Toast.makeText(getApplicationContext(),text, Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, ycross);
            toast.show();
            return false;
        }

        String url="http://www.xfunction.pub/status/apilogin";
        String getvalidate = sendHttpRequst(url);
        if(getvalidate.contains("Net"))  {
            String text = "Network problem,Check your Network setting.";

            Toast toast = Toast.makeText(getApplicationContext(),text, Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.TOP | Gravity.CENTER, 0, ycross);
            toast.show();
            return false;
        }
        else{
            if( getvalidate.substring(13,18).equals(username) && getvalidate.substring(32,36).equals(password) ){
                String text = "Wait a moment,we'll show you the main page.";
                return true;
            }
            else {
                String text = "Your username or username is't correct.";
                Toast toast = Toast.makeText(getApplicationContext(),text, Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.TOP | Gravity.CENTER, 0,ycross);
                toast.show();

                //tvTest.setText(text);
                return false;
            }
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_login, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            System.exit(0);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public String sendHttpRequst (String apiUrl){
        HttpURLConnection conn = null;
        InputStream is = null;
        ByteArrayOutputStream baos = null;
        if (isConnected()) {
            try {
                URL url = new URL(apiUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.connect();
                is = conn.getInputStream();
                int len = conn.getContentLength();
                if (len < 1) len = 1024;
                baos = new ByteArrayOutputStream(len);
                byte[] buffer = new byte[1024];
                len = 0;
                while ((len = is.read(buffer)) != -1) {
                    baos.write(buffer, 0, len);
                }
                return baos.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (baos != null) baos.close();
                    if (is != null) is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (conn != null) conn.disconnect();
            }
            return null;
        }
        else {
            return "Network problem!";
        }
    }

    public boolean isConnected(){
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }


}
