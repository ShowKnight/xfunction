package com.example.lonqi.environmentmonitoring;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.support.v7.app.ActionBarActivity;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;


public class MainActivity extends ActionBarActivity {

    public final static String EXTRA_MESSAGE = "com.mycompany.myfirstapp.MESSAGE";

    private Handler mHandler = new Handler();
    private long mExitTime;
    //private planOnClickListener MybuttonListener = new planOnClickListener();

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        Button buttononall= (Button) findViewById(R.id.buttononall);
        buttononall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.xfunction.pub/status/apionall";
                String getstatus = praseurlmessage(url);
                //Doit(getstatus);
            }
        });

        Button buttoffffall= (Button) findViewById(R.id.buttonoffall);
        buttoffffall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.xfunction.pub/status/apioffall";
                String getstatus = praseurlmessage(url);
                //Doit(getstatus);
            }
        });
        Button buttonond1= (Button) findViewById(R.id.buttonond1);
        buttonond1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://www.xfunction.pub/status/apiond1";
                String getstatus = praseurlmessage(url);
                //Doit(getstatus);

            }
        });
        Button buttonoffd1= (Button) findViewById(R.id.buttonoffd1);
        buttonoffd1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://www.xfunction.pub/status/apioffd1";
                String getstatus = praseurlmessage(url);
                //Doit(getstatus);
            }
        });
        Button buttonond2= (Button) findViewById(R.id.buttonond2);
        buttonond2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="http://www.xfunction.pub/status/apiond2";
                String getstatus = praseurlmessage(url);
                //Doit(getstatus);
            }
        });

        Button buttonoffd2= (Button) findViewById(R.id.buttonoffd2);
        buttonoffd2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "http://www.xfunction.pub/status/apioffd2";
                String getstatus = praseurlmessage(url);
                //Doit(getstatus);
            }
        });


        //Doit(getstatus);
    }


    public String praseurlmessage(String url){
        String parsedmessage = "not parsedmessage";
        String message="not message";
        message = sendHttpRequst(url);

        RadioButton radioButton1 = (RadioButton)this.findViewById(R.id.radioButton);
        RadioButton radioButton2 = (RadioButton)this.findViewById(R.id.radioButton2);
        Button buttononall = (Button)this.findViewById(R.id.buttononall);
        Button buttonoffall = (Button)this.findViewById(R.id.buttonoffall);
        Button buttonond1 = (Button)this.findViewById(R.id.buttonond1);
        Button buttonoffd1 = (Button)this.findViewById(R.id.buttonoffd1);
        Button buttonond2 = (Button)this.findViewById(R.id.buttonond2);
        Button buttonoffd2 = (Button)this.findViewById(R.id.buttonoffd2);



        if(message.indexOf("00",8) !=-1)
        {
            parsedmessage="All off";
            radioButton1.setChecked(false);
            radioButton2.setChecked(false);

            buttononall.setEnabled(true);
            buttonond1.setEnabled(true);
            buttonond2.setEnabled(true);
            buttonoffall.setEnabled(false);
            buttonoffd1.setEnabled(false);
            buttonoffd2.setEnabled(false);

        }
        else if(message.indexOf("11",8) !=-1)
        {
            parsedmessage="All on";
            radioButton1.setChecked(true);
            radioButton2.setChecked(true);

            buttononall.setEnabled(false);
            buttonond1.setEnabled(false);
            buttonond2.setEnabled(false);
            buttonoffall.setEnabled(true);
            buttonoffd1.setEnabled(true);
            buttonoffd2.setEnabled(true);
        }
        else if(message.indexOf("10",8) !=-1)
        {
            parsedmessage="D1 on, D2 off";
            radioButton1.setChecked(true);
            radioButton2.setChecked(false);

            buttononall.setEnabled(true);
            buttonond1.setEnabled(false);
            buttonond2.setEnabled(true);
            buttonoffall.setEnabled(true);
            buttonoffd1.setEnabled(true);
            buttonoffd2.setEnabled(false);
        }
        else if(message.indexOf("01",8) !=-1)
        {
            parsedmessage="D1 off, D2 on";
            radioButton1.setChecked(false);
            radioButton2.setChecked(true);

            buttononall.setEnabled(true);
            buttonond1.setEnabled(true);
            buttonond2.setEnabled(false);
            buttonoffall.setEnabled(true);
            buttonoffd1.setEnabled(false);
            buttonoffd2.setEnabled(true);
        }
        else
        {
            parsedmessage="No result";
            radioButton1.setChecked(false);
            radioButton2.setChecked(false);

            buttononall.setEnabled(false);
            buttonond1.setEnabled(false);
            buttonond2.setEnabled(false);
            buttonoffall.setEnabled(false);
            buttonoffd1.setEnabled(false);
            buttonoffd2.setEnabled(false);
        }
        return parsedmessage;
    }


    private Runnable timerTask = new  Runnable(){
        public void run(){
            String url="http://www.xfunction.pub/status/apiparams";
            String parsedmessage = "not parsedmessage";
            String message="not message";
            message = sendHttpRequst(url);
            if(isConnected()) showparams(message);
            else{
                shownetworkerror("Network error:","1.Check your network setting.",
                        "2.Maybe server dead%>_<%.","3.Find lonqi out O(n_n)O~~");
            }

            url="http://www.xfunction.pub/status/apitest";
            praseurlmessage(url);

            mHandler.postDelayed(timerTask,1000);
        }
    };
    public void shownetworkerror(String string,String reason1,String reason2,String reson3)
    {

        TextView textViewtime = (TextView)this.findViewById(R.id.textViewtime) ;
        textViewtime.setTextSize(20);
        textViewtime.setText(string);

        TextView textViewtemp = (TextView)this.findViewById(R.id.textViewtemp) ;
        textViewtemp.setTextSize(20);
        textViewtemp.setText(reason1);
        TextView textViewshi = (TextView)this.findViewById(R.id.textViewshidu)  ;
        textViewshi.setTextSize(20);
        textViewshi.setText(reason2);
        TextView textViewsmoke = (TextView)this.findViewById(R.id.textViewsmoke) ;
        textViewsmoke.setTextSize(20);
        textViewsmoke.setText(reson3);
    }
    public void showparams(String getstatus)
    {
        String temp1 = getstatus.split(":")[2];
        String shi1 = getstatus.split(":")[3];
        String smoke1 = getstatus.split(":")[4];

        String temp2 = getstatus.split(":")[7];
        String shi2 = getstatus.split(":")[8];
        String smoke2 = getstatus.split(":")[9];
        String lasttime = getstatus.split(";")[1];

        TextView textViewtime = (TextView)this.findViewById(R.id.textViewtime) ;
        textViewtime.setTextSize(18);
        textViewtime.setText("    At "+lasttime+",we get:");

        TextView textViewtemp = (TextView)this.findViewById(R.id.textViewtemp) ;
        textViewtemp.setTextSize(15);
        textViewtemp.setText("TempA:"+temp1+"\u2103"+"                 TempB:"+temp2+"\u2103");

        TextView textViewshi = (TextView)this.findViewById(R.id.textViewshidu)  ;
        textViewshi.setTextSize(15);
        textViewshi.setText("ShiduA:"+shi1+"\uff05"+"                 ShiduB:"+shi2+"\uff05");

        TextView textViewsmoke = (TextView)this.findViewById(R.id.textViewsmoke) ;
        textViewsmoke.setTextSize(15);
        textViewsmoke.setText("SmokeA:"+smoke1+"ppm"+"        SmokeB:"+smoke2+"ppm");
    }
    protected void onResume(){
        super.onResume();
        mHandler.post(timerTask);
    }
    protected void onPause()
    {
        super.onPause();
        mHandler.removeCallbacks(timerTask);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            System.exit(0);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if ((System.currentTimeMillis() - mExitTime) > 2000) {
                Object mHelperUtils;
                Toast.makeText(this, "Press twice to exit ", Toast.LENGTH_SHORT).show();
                mExitTime = System.currentTimeMillis();

            } else {
                finish();
            }
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

/*
  public void Doit(String getstatus)
    {
        //TextView textView = new TextView(this);


        TextView textView = (TextView)this.findViewById(R.id.textView)  ;
        textView.setTextSize(40);
        textView.setText(getstatus);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void sendMessage(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, DisplayMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        //intent.putExtra(EXTRA_MESSAGE, message);
        startActivity(intent);
    }

    public void getMessageoffall(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GetMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "offall");
        startActivity(intent);
    }
    public void getMessageonall(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GetMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "onall");
        startActivity(intent);
    }
    public void getMessageond1(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GetMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "ond1");
        startActivity(intent);
    }
    public void getMessageoffd1(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GetMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "offd1");
        startActivity(intent);
    }
    public void getMessageond2(View view) {
        // Do something in response to button

       Intent intent = new Intent(this, GetMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "ond2");
        startActivity(intent);

    }
    public void getMessageoffd2(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, GetMessageActivity.class);
        //EditText editText = (EditText) findViewById(R.id.edit_message);
        //String message = editText.getText().toString();
        intent.putExtra(EXTRA_MESSAGE, "offd2");
        startActivity(intent);
    }*/

    public String sendHttpRequst (String apiUrl){
        HttpURLConnection conn = null;
        InputStream is = null;
        ByteArrayOutputStream baos = null;
        if (isConnected()) {
            try {
                URL url = new URL(apiUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.connect();
                is = conn.getInputStream();
                int len = conn.getContentLength();
                if (len < 1) len = 1024;
                baos = new ByteArrayOutputStream(len);
                byte[] buffer = new byte[1024];
                len = 0;
                while ((len = is.read(buffer)) != -1) {
                    baos.write(buffer, 0, len);
                }
                return baos.toString();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (baos != null) baos.close();
                    if (is != null) is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                if (conn != null) conn.disconnect();
            }
            return null;
        }
        else {
            return "Network problem!";
        }
    }

    public boolean isConnected(){
        ConnectivityManager connMgr = (ConnectivityManager) getSystemService(this.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        if (networkInfo != null && networkInfo.isConnected())
            return true;
        else
            return false;
    }
}
